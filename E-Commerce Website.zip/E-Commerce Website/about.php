<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>About Us</title>
</head>
<?php
	include ("partials/head.php");
?>
<body class="animsition">
	<?php
		include ("partials/header.php");
	?>


	<!-- Title page -->
	<section class="bg-img1 txt-center p-lr-15 p-tb-92" style="background-image: url('images/bg-03-whiten.jpg');">
		<h2 class="ltext-105 cl0 txt-center">
			About
		</h2>
	</section>	


	<!-- Content page -->
	<section class="bg0 p-t-75 p-b-120">
		<div class="container">
			<div class="row p-b-148">
				<div class="col-md-7 col-lg-8">
					<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							Our Story
						</h3>

						<p class="stext-113 cl6 p-b-26">
							The Zynx’s Children Shoe Boutique was founded in Rizal, Philippines in 1969 by Celso Del Castillo II and Christian Lagrana. At first, they were a simple shoemaker who offers products and services like shoe repair, shine and simple restoration and had no permanent store location before deciding that children shoes had the most growth potential.
						</p>

						<p class="stext-113 cl6 p-b-26">
							In 2019, The Zynx’s Children Shoe Boutique purchased the rights to the e-commerce industry and in early 2020, launched product in select stores and online. This iconic brand features colorful designs in playful, bow-to-toe collections that celebrate childhood and help families look their best for any occasion. Together, these two brands embrace the kids we love and inspire them to live, learn and love their childhood.
						</p>

						<p class="stext-113 cl6 p-b-26">
							Any questions? Let us know in store at Cluster 7, Unit 3V, Cambridge Village, Cainta, Rizal or call us on (+63) 92 748 7561
						</p>
					</div>
				</div>

				<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
					<div class="how-bor1 ">
						<div class="hov-img0">
							<img src="images/ian-resized.jpg" alt="IMG">
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="order-md-2 col-md-7 col-lg-8 p-b-30">
					<div class="p-t-7 p-l-85 p-l-15-lg p-l-0-md">
						<h3 class="mtext-111 cl2 p-b-16">
							Our Mission and Vision
						</h3>

						<p class="stext-113 cl6 p-b-26">
							Our company’s only vision yet known to be the most important, is to be a distinguished kid’s footwear brand known worldwide for the quality products, setting new trends and lifestyles. Our company offers continuous values added product to our customers. To accomplish this, we focus on exceptional design, innovation, quality, convenience and interactive communication— bringing the best potential of the company could have.
						</p>

						<div class="bor16 p-l-29 p-b-9 m-t-22">
							<p class="stext-114 cl6 p-r-40 p-b-11">
								“You must be very patient, very persistent. The world isn’t going to shower gold coins on you just because you have a good idea. You’re going to have to work like crazy to bring that idea to the attention of people. They’re not going to buy it unless they know about it.”
							</p>

							<span class="stext-111 cl8">
								- Herb Kelleher's, Founder of Southwest Airlines
							</span>
						</div>
					</div>
				</div>

				<div class="order-md-1 col-11 col-md-5 col-lg-4 m-lr-auto p-b-30">
					<div class="how-bor2">
						<div class="hov-img0">
							<img src="images/cadc-resized.jpg" alt="IMG">
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>	
	
		

	<!-- Footer -->
	<?php 
		include ('partials/footer.php');
	?>
	
</body>
</html>