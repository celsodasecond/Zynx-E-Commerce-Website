<?php 

$host="localhost";
$user="id17172523_admin";
$password="aCSijia>q#i!n46<";
$dbname="id17172523_ecommercewebsite";

$connect=mysqli_connect($host, $user, $password, $dbname);

?>